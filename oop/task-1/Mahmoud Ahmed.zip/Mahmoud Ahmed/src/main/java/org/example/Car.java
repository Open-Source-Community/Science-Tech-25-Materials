package org.example;

public class Car extends Vehicle implements IUpgradeable {

    public Car(String modelName)
    {
        super(modelName);
    }

    public void Accelerate() {
        System.out.println(getModelName() + " (Car) is accelerating");
    }

    public void Display()
    {
        System.out.println("This is a car: " + getModelName());
    }

    public void Upgrade() {
        System.out.println(getModelName() + " (Car) engine is being upgraded");
    }
}
