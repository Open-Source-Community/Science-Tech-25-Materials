package org.example;

public class Bike extends Vehicle implements IUpgradeable {

    public Bike(String modelName)
    {
        super(modelName);
    }

    public void Accelerate() {
        System.out.println(getModelName() + " (Bike) is accelerating");
    }

    public void Display()
    {
        System.out.println("This is a bike: " + getModelName());
    }

    public void Upgrade() {
        System.out.println(getModelName() + " (Bike) engine is being upgraded");
    }
}
