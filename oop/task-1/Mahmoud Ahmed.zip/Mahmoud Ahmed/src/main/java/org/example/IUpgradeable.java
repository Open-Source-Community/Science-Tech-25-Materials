package org.example;

public interface IUpgradeable {

    public abstract void Upgrade();
}
