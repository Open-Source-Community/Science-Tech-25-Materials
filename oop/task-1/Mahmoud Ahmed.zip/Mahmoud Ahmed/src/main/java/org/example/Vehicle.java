package org.example;

public abstract class Vehicle
{
    private String modelName;

    private String type;

    public Vehicle(String modelName)
    {
        this.modelName = modelName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getModelName()
    {
        return this.modelName;
    }

    public void setModelName(String modelName)
    {
        this.modelName = modelName;
    }

    public void Start()
    {
        System.out.println(getModelName() + " is starting");
    }

    public void Stop() {
        System.out.println(getType() +" "+ getModelName() + " is stopping");
    }

    public abstract void Accelerate();

    public abstract void Display();
}
