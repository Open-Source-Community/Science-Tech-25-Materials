package org.example;

public class Main {
    public static void main(String[] args)
    {
        Car car = new Car("Tesla model 5");
        Bike bike = new Bike("Harley Davidson");
        car.Start();
        car.Accelerate();
        car.Stop();
        bike.Start();
        bike.Accelerate();
        bike.Stop();
        car.Upgrade();
        bike.Upgrade();
        car.Display();
        bike.Display();
    }
}