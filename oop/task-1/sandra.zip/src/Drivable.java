public interface Drivable {

    void start();
    void stop();
    void accelerate();

}
