public interface Upgradeable
{
    void upgradeEngine();
}
